Inspired by Jérôme Jaglale and his article http://jeromejaglale.com/doc/php/google_calendar_api
More docs at - https://developers.google.com/google-apps/calendar/v1/developers_guide_php?hl=ru&csw=1
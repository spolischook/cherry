<?php

namespace Spolischook\GoogleCalendarBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class GoogleCalendarBundle extends Bundle
{
}
